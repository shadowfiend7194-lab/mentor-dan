from datetime import date, timedelta
from io import BytesIO
from statistics import mean
from zoneinfo import ZoneInfo

import matplotlib.pyplot as plt

from database.connection import get_connection
from database.habits import is_habit_scheduled_on_date
from services.subscription import user_has_pro
from services.dan.pro_progress import get_all_habits_progress


MOSCOW = ZoneInfo("Europe/Moscow")


# =========================================================
# НЕДЕЛЯ: ПОНЕДЕЛЬНИК — ВОСКРЕСЕНЬЕ
# =========================================================

def get_report_week(today=None):
    if today is None:
        today = date.today()

    monday = today - timedelta(days=today.weekday())
    sunday = monday + timedelta(days=6)
    return monday, sunday


# =========================================================
# ЧЕК-ИНЫ ЗА НЕДЕЛЮ
# =========================================================

def _get_checkin_metrics(user_id, start, end):
    conn = get_connection()
    cursor = conn.cursor()

    cursor.execute(
        """
        SELECT
            morning_energy,
            morning_sleep,
            morning_mood,
            morning_stress,
            evening_score
        FROM checkins
        WHERE user_id = ?
        AND date >= ?
        AND date <= ?
        ORDER BY date ASC
        """,
        (user_id, start.isoformat(), end.isoformat()),
    )

    rows = cursor.fetchall()
    conn.close()

    def avg(index):
        values = [float(row[index]) for row in rows if row[index] is not None]
        return round(mean(values), 1) if values else 0.0

    return {
        "energy": avg(0),
        "sleep": avg(1),
        "mood": avg(2),
        "stress": avg(3),
        "evening": avg(4),
        "days": len(rows),
    }


# =========================================================
# СТАБИЛЬНОСТЬ ПРИВЫЧЕК ЗА НЕДЕЛЮ
# =========================================================

def _habit_week_stability(user_id, start, end):
    conn = get_connection()
    cursor = conn.cursor()
    cursor.execute(
        """
        SELECT id, name, habit_type, frequency, schedule_days
        FROM habits
        WHERE user_id = ?
        AND active = 1
        AND pro_status != 'frozen'
        ORDER BY id ASC
        """,
        (user_id,),
    )
    habits = cursor.fetchall()

    result = []

    for habit_id, name, habit_type, frequency, schedule_days in habits:
        cursor.execute(
            """
            SELECT date, completed
            FROM habit_logs
            WHERE habit_id = ?
            AND date >= ?
            AND date <= ?
            """,
            (habit_id, start.isoformat(), end.isoformat()),
        )
        logs = {row[0]: bool(row[1]) for row in cursor.fetchall()}

        scheduled = 0
        completed = 0
        day = start
        while day <= end:
            habit = {
                "frequency": frequency,
                "schedule_days": schedule_days,
            }
            if is_habit_scheduled_on_date(habit, day):
                scheduled += 1
                if logs.get(day.isoformat(), False):
                    completed += 1
            day += timedelta(days=1)

        stability = round(completed / scheduled * 100) if scheduled else 0
        result.append({
            "id": habit_id,
            "name": name,
            "type": habit_type,
            "scheduled": scheduled,
            "completed": completed,
            "stability": stability,
        })

    conn.close()

    active = [item for item in result if item["scheduled"] > 0]
    overall = round(
        sum(item["completed"] for item in active)
        / sum(item["scheduled"] for item in active)
        * 100
    ) if active and sum(item["scheduled"] for item in active) else 0

    return result, overall


# =========================================================
# ПРЕДЫДУЩАЯ НЕДЕЛЯ
# =========================================================

def _previous_week_metrics(user_id, start):
    previous_end = start - timedelta(days=1)
    previous_start = previous_end - timedelta(days=6)
    checkins = _get_checkin_metrics(user_id, previous_start, previous_end)
    _, stability = _habit_week_stability(user_id, previous_start, previous_end)
    return checkins, stability


# =========================================================
# РАДАР
# =========================================================

def build_radar_chart(metrics):
    labels = [
        "Стабильность",
        "Энергия",
        "Сон",
        "Настрой",
        "Контроль\nстресса",
    ]

    values = [
        float(metrics["stability"]),
        float(metrics["energy"]) * 10,
        float(metrics["sleep"]) * 10,
        float(metrics["mood"]) * 10,
        max(0.0, 100.0 - float(metrics["stress"]) * 10),
    ]

    values += values[:1]

    import math
    angles = [
        2 * math.pi * index / len(labels)
        for index in range(len(labels))
    ]
    angles += angles[:1]

    fig = plt.figure(figsize=(7, 7), dpi=150)
    ax = fig.add_subplot(111, polar=True)

    ax.set_theta_offset(math.pi / 2)
    ax.set_theta_direction(-1)
    ax.set_ylim(0, 100)
    ax.set_yticks([20, 40, 60, 80, 100])
    ax.set_yticklabels(["20", "40", "60", "80", "100"])
    ax.set_xticks(angles[:-1])
    ax.set_xticklabels(labels, fontsize=10)
    ax.set_title("Твоя неделя", pad=25, fontsize=16, fontweight="bold")

    ax.plot(angles, values, linewidth=2.5)
    ax.fill(angles, values, alpha=0.18)
    ax.grid(True, alpha=0.35)

    fig.text(
        0.5,
        0.035,
        "Дэн смотрит на систему целиком: ресурс, состояние и стабильность.",
        ha="center",
        fontsize=9,
    )

    output = BytesIO()
    output.name = "dan_weekly_radar.png"
    fig.savefig(output, format="png", bbox_inches="tight")
    plt.close(fig)
    output.seek(0)
    return output


# =========================================================
# ФОРМУЛИРОВКИ
# =========================================================

def _trend(current, previous, label, positive=True):
    if not previous:
        return None

    delta = round(current - previous)
    if delta == 0:
        return f"{label}: без заметных изменений"

    sign = "+" if delta > 0 else ""
    if not positive:
        direction = "лучше" if delta < 0 else "хуже"
    else:
        direction = "лучше" if delta > 0 else "ниже"

    return f"{label}: {sign}{delta} — {direction}, чем на прошлой неделе"


def build_weekly_report(user_id, today=None):
    if not user_has_pro(user_id):
        return None, None

    if today is None:
        today = datetime_now_moscow().date()

    start, end = get_report_week(today)
    current = _get_checkin_metrics(user_id, start, end)
    habits, stability = _habit_week_stability(user_id, start, end)
    previous, previous_stability = _previous_week_metrics(user_id, start)

    metrics = {
        "stability": stability,
        "energy": current["energy"],
        "sleep": current["sleep"],
        "mood": current["mood"],
        "stress": current["stress"],
    }

    radar = build_radar_chart(metrics)

    lines = [
        "💎 <b>Твой недельный анализ</b>",
        "",
        f"📅 <b>{start.strftime('%d.%m')} — {end.strftime('%d.%m.%Y')}</b>",
        "",
    ]

    if current["days"] == 0 and not habits:
        lines += [
            "Дэн пока почти ничего не может сравнить: за неделю мало данных.",
            "Но это не проблема. Сначала нужно дать системе материал — потом появятся закономерности.",
            "",
        ]
    else:
        lines += [
            "🧠 <b>Что я вижу</b>",
            "",
            f"Ты удерживал привычки на уровне <b>{stability}%</b>.",
        ]

        if previous_stability:
            delta = stability - previous_stability
            if delta > 0:
                lines.append(f"Это <b>+{delta}%</b> к прошлой неделе. Система становится устойчивее.")
            elif delta < 0:
                lines.append(f"Это <b>{delta}%</b> к прошлой неделе. Здесь важно понять, где именно начал проседать ритм.")
            else:
                lines.append("По сравнению с прошлой неделей стабильность почти не изменилась.")

        lines += [
            "",
            f"⚡ Энергия — <b>{current['energy']}/10</b>",
            f"😴 Сон — <b>{current['sleep']}/10</b>",
            f"🙂 Настрой — <b>{current['mood']}/10</b>",
            f"😰 Стресс — <b>{current['stress']}/10</b>",
            "",
        ]

        trends = [
            _trend(current["energy"], previous["energy"], "Энергия"),
            _trend(current["sleep"], previous["sleep"], "Сон"),
            _trend(current["mood"], previous["mood"], "Настрой"),
            _trend(current["stress"], previous["stress"], "Стресс", positive=False),
        ]
        trends = [item for item in trends if item]

        if trends:
            lines.append("📈 <b>Динамика</b>")
            lines.extend(trends)
            lines.append("")

        active_habits = [h for h in habits if h["scheduled"]]
        if active_habits:
            best = max(active_habits, key=lambda x: x["stability"])
            worst = min(active_habits, key=lambda x: x["stability"])

            lines += [
                "🎯 <b>Привычки</b>",
                "",
                f"Лучше всего держалась: <b>{best['name']}</b> — {best['stability']}%.",
            ]

            if worst["id"] != best["id"]:
                lines.append(
                    f"Слабое место недели: <b>{worst['name']}</b> — {worst['stability']}%."
                )

            lines.append("")

        # Простые проверяемые закономерности вместо выдуманных причин.
        if current["sleep"] and current["energy"]:
            if current["sleep"] <= 5 and current["energy"] <= 5:
                lines += [
                    "🔎 <b>Закономерность</b>",
                    "Сон и энергия одновременно находятся ниже середины шкалы. Это первая связка, на которую я бы посмотрел на следующей неделе.",
                    "",
                ]
            elif current["sleep"] >= 7 and current["energy"] >= 7:
                lines += [
                    "🔎 <b>Закономерность</b>",
                    "Сон и энергия держатся высоко одновременно. Похоже, восстановление сейчас работает в твою пользу.",
                    "",
                ]

        # Фокус выбираем по самому явному ограничителю.
        if current["sleep"] and current["sleep"] <= 5:
            focus = "Сделай сон главным фокусом недели. Не пытайся одновременно чинить всё остальное."
        elif current["stress"] >= 7:
            focus = "Сначала снизь перегрузку. Тебе сейчас важнее сохранить ресурс, чем добавить ещё одну задачу."
        elif stability < 60:
            focus = "Не добавляй новую нагрузку. Выбери одну привычку и доведи её выполнение до устойчивого ритма."
        elif stability >= 80:
            focus = "Не усложняй систему. Сохрани то, что уже работает, и улучшай только один элемент за раз."
        else:
            focus = "Выбери одну привычку, которая чаще всего проседает, и сделай её главным фокусом следующей недели."

        lines += [
            "⚡ <b>Фокус следующей недели</b>",
            focus,
            "",
            "Я бы не пытался изменить всю жизнь за семь дней. Намного полезнее найти одну точку, которая даст следующий устойчивый шаг.",
        ]

    text = "\n".join(lines)
    return text, radar


def datetime_now_moscow():
    from datetime import datetime
    return datetime.now(MOSCOW)
