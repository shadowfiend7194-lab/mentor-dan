from services.dan.pro_weekly_report import build_weekly_report


def generate_weekly_report(user_id):
    result = build_weekly_report(user_id)
    if not result:
        return "📊 <b>Недельный анализ</b>\n\nНедельный расширенный анализ доступен в PRO."
    text, _chart = result
    return text
